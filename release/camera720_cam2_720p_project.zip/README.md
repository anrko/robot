# Camera720 CAM2 720p project

Gowin GW5AT-60B camera capture and RGB565 UDP/RGMII project.

The video stream includes a vendor-independent Verilog attitude HUD in `camera720/attitude_osd_rgb565.v`. Current roll, pitch, and yaw values are placeholders (`+000.0°`). The panel uses a dark translucent tint so the camera image remains visible underneath.

Open `camera720.gprj` in Gowin EDA. See `CAMERA720_CAM2_烧录说明.md` for board setup and burn instructions.
